import { useState } from 'react';

function App() {
  const [filmes, setFilmes] = useState([]);
  const [novoFilme, setNovoFilme] = useState('');
  const [editandoIndex, setEditandoIndex] = useState(null);

  const adicionarFilme = () => {
    if (!novoFilme.trim()) return;
    if (editandoIndex !== null) {
      const atualizados = [...filmes];
      atualizados[editandoIndex] = novoFilme;
      setFilmes(atualizados);
      setEditandoIndex(null);
    } else {
      setFilmes([...filmes, novoFilme]);
    }
    setNovoFilme('');
  };

  const editarFilme = (index) => {
    setNovoFilme(filmes[index]);
    setEditandoIndex(index);
  };

  const removerFilme = (index) => {
    const atualizados = filmes.filter((_, i) => i !== index);
    setFilmes(atualizados);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-purple-200 flex items-center justify-center p-4">
      <div className="bg-white shadow-xl rounded-xl p-6 w-full max-w-xl space-y-5">
        <h1 className="text-3xl font-bold text-center text-purple-700 flex items-center justify-center gap-2">
          🎬 Locadora de Filmes
        </h1>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            className="flex-1 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400"
            placeholder="Nome do filme"
            value={novoFilme}
            onChange={(e) => setNovoFilme(e.target.value)}
          />
          <button
            className="bg-purple-600 hover:bg-purple-700 text-white font-medium px-4 py-2 rounded"
            onClick={adicionarFilme}
          >
            {editandoIndex !== null ? 'Atualizar' : 'Adicionar'}
          </button>
        </div>

        <ul className="space-y-3">
          {filmes.map((filme, index) => (
            <li
              key={index}
              className="flex justify-between items-center bg-gray-100 p-3 rounded shadow-sm"
            >
              <span className="text-gray-800 font-medium">{filme}</span>
              <div className="flex gap-3">
                <button
                  className="text-blue-600 hover:underline"
                  onClick={() => editarFilme(index)}
                >
                  Editar
                </button>
                <button
                  className="text-red-600 hover:underline"
                  onClick={() => removerFilme(index)}
                >
                  Excluir
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
